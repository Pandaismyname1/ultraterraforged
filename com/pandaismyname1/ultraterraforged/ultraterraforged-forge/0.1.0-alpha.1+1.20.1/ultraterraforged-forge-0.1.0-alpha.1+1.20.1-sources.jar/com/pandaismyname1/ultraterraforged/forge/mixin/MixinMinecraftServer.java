package com.pandaismyname1.ultraterraforged.forge.mixin;

import java.net.Proxy;

import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.datafixers.DataFixer;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.Services;
import net.minecraft.server.WorldStem;
import net.minecraft.server.level.progress.ChunkProgressListenerFactory;
import net.minecraft.server.packs.repository.PackRepository;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.level.storage.LevelStorageSource;
import com.pandaismyname1.ultraterraforged.server.UTFMinecraftServer;
import com.pandaismyname1.ultraterraforged.world.worldgen.feature.template.template.FeatureTemplateManager;

@Implements(@Interface(iface = UTFMinecraftServer.class, prefix = "ultraterraforged$UTFMinecraftServer$"))
@Mixin(MinecraftServer.class)
public class MixinMinecraftServer {
	private FeatureTemplateManager templateManager;

	@Inject(
		method = "<init>(Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Lnet/minecraft/server/WorldStem;Ljava/net/Proxy;Lcom/mojang/datafixers/DataFixer;Lnet/minecraft/server/Services;Lnet/minecraft/server/level/progress/ChunkProgressListenerFactory;)V",
		at = @At("TAIL")
	)
	public void MinecraftServer(Thread thread, LevelStorageSource.LevelStorageAccess arg2, PackRepository arg22, WorldStem arg3, Proxy proxy, DataFixer dataFixer, Services arg4, ChunkProgressListenerFactory arg5, CallbackInfo callback) {
		this.templateManager = new FeatureTemplateManager((MinecraftServer) (Object) this, this.getResourceManager());
	}
	
	public FeatureTemplateManager ultraterraforged$UTFMinecraftServer$getFeatureTemplateManager() {
		return this.templateManager;
	}

	@Inject(
		// Forge-patched lambda (javac name); $26 on Forge 47.4 and NeoForge 47.1 for 1.20.1
		method = "lambda$reloadResources$26",
		remap = false,
		at = @At("TAIL")
	)
	private void onReloadResources(CallbackInfo callback) {
		this.templateManager.onReload(this.getResourceManager());
	}
	
	@Shadow
	private ResourceManager getResourceManager() {
		throw new UnsupportedOperationException();
	}
}
