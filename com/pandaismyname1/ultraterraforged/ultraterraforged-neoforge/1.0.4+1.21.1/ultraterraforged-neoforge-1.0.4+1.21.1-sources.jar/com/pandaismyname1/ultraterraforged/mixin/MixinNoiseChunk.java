package com.pandaismyname1.ultraterraforged.mixin;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.core.SectionPos;
import net.minecraft.server.level.ColumnPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Aquifer;
import net.minecraft.world.level.levelgen.Beardifier;
import net.minecraft.world.level.levelgen.DensityFunction;
import net.minecraft.world.level.levelgen.DensityFunctions;
import net.minecraft.world.level.levelgen.NoiseChunk;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.levelgen.NoiseRouter;
import net.minecraft.world.level.levelgen.NoiseSettings;
import net.minecraft.world.level.levelgen.RandomState;
import com.pandaismyname1.ultraterraforged.data.preset.settings.Preset;
import com.pandaismyname1.ultraterraforged.world.worldgen.GeneratorContext;
import com.pandaismyname1.ultraterraforged.world.worldgen.UTFRandomState;
import com.pandaismyname1.ultraterraforged.world.worldgen.densityfunction.CellSampler;

// after mods that overwrite NoiseChunk's methods (Generator Accelerator overwrites computePreliminarySurfaceLevel): a
// mixin can only inject into a method another one merged if it comes after it, and NoiseChunk failed to load otherwise
@Mixin(value = NoiseChunk.class, priority = 1100)
class MixinNoiseChunk {
	private RandomState randomState;
	private int chunkX, chunkZ;
	private int generationHeight;
	private CellSampler.ChunkCells chunk;
    private NoiseGeneratorSettings generatorSettings;
	
	@Shadow
    @Final
    private DensityFunction initialDensityNoJaggedness;
    
	@Shadow
    @Final
	int firstNoiseX;
	
	@Shadow
    @Final
    int firstNoiseZ;
	
	@Shadow
    @Final
	private int cellCountXZ;
	
	@Shadow
	private int cellCountY;
	
	@Shadow
    @Final
    private int cellHeight;
	
	@Redirect(
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/level/levelgen/RandomState;router()Lnet/minecraft/world/level/levelgen/NoiseRouter;"
		),
		method = "<init>"
	)
	private NoiseRouter NoiseChunk(RandomState randomState1, int cellCountXZ, RandomState randomState2, int minBlockX, int minBlockZ, NoiseSettings noiseSettings, DensityFunctions.BeardifierOrMarker beardifierOrMarker, NoiseGeneratorSettings noiseGeneratorSettings) {
		this.randomState = randomState1;
		this.chunkX = SectionPos.blockToSectionCoord(minBlockX);
		this.chunkZ = SectionPos.blockToSectionCoord(minBlockZ);
		this.generatorSettings = noiseGeneratorSettings;
		GeneratorContext generatorContext;
		if((Object) this.randomState instanceof UTFRandomState utfRandomState && (generatorContext = utfRandomState.generatorContext()) != null) {
			// a single column (a structure asking for the height) reads its chunk's tile too, on whichever thread asks;
			// in a pass that only looks it reads the heightmap, and isn't cut off at the tile's highest point either
			this.chunk = CellSampler.chunkCells(generatorContext, cellCountXZ, this.chunkX, this.chunkZ);
			this.generationHeight = this.chunk != null ? generatorContext.lookup.getGenerationHeight(this.chunkX, this.chunkZ, noiseGeneratorSettings, true) : noiseSettings.height();
			this.cellCountY = Math.min(this.cellCountY, this.generationHeight / this.cellHeight);
		} else {
			this.generationHeight = noiseSettings.height();
		}
		return this.randomState.router();
	}
	
	@ModifyVariable(
		method = "<init>",
		at = @At("HEAD"),
		name = "fluidPicker",
		index = 7,
		ordinal = 0,
		argsOnly = true
	)
	//TODO clean this up
	private static Aquifer.FluidPicker modifyFluidPicker(Aquifer.FluidPicker fluidPicker, int cellCountXZ, RandomState randomState, int minBlockX, int minBlockZ, NoiseSettings noiseSettings, DensityFunctions.BeardifierOrMarker beardifierOrMarker, NoiseGeneratorSettings noiseGeneratorSettings) {
		if((Object) randomState instanceof UTFRandomState utfRandomState) {
			@Nullable
			Preset preset = utfRandomState.preset();
			@Nullable
			GeneratorContext generatorContext;
			if(preset != null && (generatorContext = utfRandomState.generatorContext()) != null) {
				int lavaLevel = preset.world().properties.lavaLevel;
		        Aquifer.FluidStatus lava = new Aquifer.FluidStatus(lavaLevel, Blocks.LAVA.defaultBlockState());
		        int seaLevel = noiseGeneratorSettings.seaLevel();
		        Aquifer.FluidStatus defaultFluid = new Aquifer.FluidStatus(seaLevel, noiseGeneratorSettings.defaultFluid());
		        return (x, y, z) -> {
		        	if (y < Math.min(lavaLevel, seaLevel)) {
		                return lava;
		            }
		            return defaultFluid;
		        };
			}
		}
		return fluidPicker;
	}

	@Inject(
		at = @At("HEAD"),
		method = "wrapNew",
		cancellable = true
	)
	private void wrapNew(DensityFunction function, CallbackInfoReturnable<DensityFunction> callback) {
		if((Object) this.randomState instanceof UTFRandomState randomState && function instanceof CellSampler mapped) {
			callback.setReturnValue(mapped.new CacheChunk(this.chunk));
		}
	}
	@Redirect(
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/level/levelgen/NoiseSettings;height()I"
		),
		require = 1,
		method = "computePreliminarySurfaceLevel"
	)
	private int computePreliminarySurfaceLevel(NoiseSettings settings, long packedPos) {
        int blockX = ColumnPos.getX(packedPos);
        int blockZ = ColumnPos.getZ(packedPos);
        int generationHeight;
		GeneratorContext generatorContext;
        if((Object) this.randomState instanceof UTFRandomState utfRandomState && (generatorContext = utfRandomState.generatorContext()) != null) {
        	generationHeight = generatorContext.lookup.getGenerationHeight(SectionPos.blockToSectionCoord(blockX), SectionPos.blockToSectionCoord(blockZ), this.generatorSettings, false);
        } else {
        	generationHeight = this.generatorSettings.noiseSettings().height();
        }
        return generationHeight;
	}
}