package com.pandaismyname1.ultraterraforged.platform.neoforge;

import java.util.concurrent.CompletableFuture;

import net.minecraft.core.HolderLookup;
import net.minecraft.data.DataProvider;
import net.minecraft.data.PackOutput;
import net.minecraft.data.registries.RegistriesDatapackGenerator;

public final class DataGenUtilImpl {

	public static DataProvider createRegistryProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> providerLookup) {
		// the world layer, which NeoForge extends with mods' datapack registries
		return RegistriesDatapackGenerator.forWorldLayer(output, providerLookup);
	}
}