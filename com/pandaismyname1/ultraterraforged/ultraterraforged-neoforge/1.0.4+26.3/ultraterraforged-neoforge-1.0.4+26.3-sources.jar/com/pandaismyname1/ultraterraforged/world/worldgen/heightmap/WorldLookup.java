package com.pandaismyname1.ultraterraforged.world.worldgen.heightmap;

import org.jetbrains.annotations.Nullable;

import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.levelgen.NoiseSettings;
import com.pandaismyname1.ultraterraforged.world.worldgen.GeneratorContext;
import com.pandaismyname1.ultraterraforged.world.worldgen.WorldGenFlags;
import com.pandaismyname1.ultraterraforged.world.worldgen.cell.Cell;
import com.pandaismyname1.ultraterraforged.world.worldgen.rivermap.Rivermap;
import com.pandaismyname1.ultraterraforged.world.worldgen.cell.noise.CellSampler;
import com.pandaismyname1.ultraterraforged.world.worldgen.terrain.TerrainType;
import com.pandaismyname1.ultraterraforged.world.worldgen.tile.Tile;
import com.pandaismyname1.ultraterraforged.world.worldgen.tile.TileCache;

public class WorldLookup {
	// the height of the preset's noise cells (its interpolated density); the filled height ends on a cell's top
	private static final int CELL_HEIGHT = 8;
	private GeneratorContext context;
	private float waterLevel;
	private float beachLevel;
	private TileCache cache;
	private Levels levels;
	// whether chunks are generated only as high as their terrain: off for a world preview, which reads every section
	private volatile boolean cullNoiseSections = true;
	// whether single columns may be a quick guess in this world: a world preview's, which only looks
	private volatile boolean approximateColumns;
	
	public WorldLookup(GeneratorContext context) {
		this.context = context;
		this.cache = context.cache;
		this.waterLevel = context.levels.water;
		this.beachLevel = context.levels.water(5);
		this.levels = context.levels;
	}

	public void setCullNoiseSections(boolean cullNoiseSections) {
		this.cullNoiseSections = cullNoiseSections;
	}

	public void setApproximateColumns(boolean approximateColumns) {
		this.approximateColumns = approximateColumns;
	}

	// whether a lookup here reads the heightmap alone, without the tiles' filters, instead of making the tile: in a
	// world preview, and in a pass that only looks (WorldGenFlags.approximately); never where structures are placed
	public boolean approximate() {
		return this.approximateColumns || WorldGenFlags.approximateLookups();
	}

	public int getGenerationHeight(int chunkX, int chunkZ, NoiseGeneratorSettings generatorSettings, boolean load) {
		NoiseSettings noiseSettings = generatorSettings.noiseSettings();
		
		int minY = noiseSettings.minY();
		int genHeight = noiseSettings.height();
		int cellHeight = CELL_HEIGHT;
		
		if(!this.cullNoiseSections) {
			return genHeight;
		}
		
		@Nullable
		Tile tile = load ? this.cache.provideAtChunk(chunkX, chunkZ) : this.cache.provideAtChunkIfPresent(chunkX, chunkZ);
		if(tile != null) {
			Tile.Chunk chunk = tile.getChunkReader(chunkX, chunkZ);
			int generationHeight = Math.max(generatorSettings.seaLevel(), this.levels.scale(chunk.getHighestPoint()));
			return Math.min(genHeight, ((-minY + generationHeight) / cellHeight + 1) * cellHeight);
		} else {
			return genHeight;
		}
	}

	public boolean apply(Cell cell, int x, int z) {
		return this.apply(cell, x, z, false);
	}

	// the cell as the chunk there is generated with it, from its tile, made if it has to be: where a structure is
	// placed. In a pass that only looks, the heightmap's, which is quick. Either way the same on whichever thread
	// asks and whenever, as neither depends on which tiles happen to be made
	public boolean applyAsGenerated(Cell cell, int x, int z) {
		if (this.approximate()) {
			return this.compute(cell, x, z);
		}
		return this.apply(cell, x, z, true);
	}

	public boolean apply(Cell cell, int x, int z, boolean load) {
		if (load && this.computeAccurate(cell, x, z)) {
			return true;
		}
		if (this.computeCached(cell, x, z)) {
			return true;
		}
		return this.compute(cell, x, z);
	}

	private boolean computeAccurate(Cell cell, int x, int z) {
		int rx = this.cache.chunkToTile(x >> 4);
		int rz = this.cache.chunkToTile(z >> 4);
		Tile tile = this.cache.provide(rx, rz);
		Cell c = tile.lookup(x, z);
		if (c != null) {
			cell.copyFrom(c);
		}
		return cell.terrain != null;
	}

	private boolean computeCached(Cell cell, int x, int z) {
		int rx = this.cache.chunkToTile(x >> 4);
		int rz = this.cache.chunkToTile(z >> 4);
		Tile tile = this.cache.provideIfPresent(rx, rz);
		if (tile != null) {
			Cell c = tile.lookup(x, z);
			if (c != null) {
				cell.copyFrom(c);
			}
			return cell.terrain != null;
		}
		return false;
	}

	public boolean compute(Cell cell, int x, int z) {
		Heightmap heightmap = this.context.localHeightmap.get();
		CellSampler.Provider cellProvider = heightmap.cellProvider();
		
		@Nullable
		Cell oldCell = cellProvider.getCacheCell();
		
		cellProvider.setCacheCell(cell);
		try {
			heightmap.applyContinent(cell, x, z);
			heightmap.applyTerrain(cell, x, z, Rivermap.get(cell, null, heightmap));
			heightmap.applyClimate(cell, x, z);
			if (cell.terrain == TerrainType.COAST && cell.height > this.waterLevel && cell.height <= this.beachLevel) {
				cell.terrain = TerrainType.BEACH;
			}
			heightmap.applyPost(cell, x, z);
		} finally {
			cellProvider.setCacheCell(oldCell);
		}
		return false;
	}
}
