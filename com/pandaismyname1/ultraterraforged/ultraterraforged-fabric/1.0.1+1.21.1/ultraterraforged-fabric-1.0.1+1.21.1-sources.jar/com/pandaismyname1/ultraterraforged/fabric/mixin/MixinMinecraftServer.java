package com.pandaismyname1.ultraterraforged.fabric.mixin;

import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.packs.resources.ResourceManager;
import com.pandaismyname1.ultraterraforged.server.UTFMinecraftServer;
import com.pandaismyname1.ultraterraforged.world.worldgen.feature.template.template.FeatureTemplateManager;

@Implements(@Interface(iface = UTFMinecraftServer.class, prefix = "ultraterraforged$UTFMinecraftServer$"))
@Mixin(MinecraftServer.class)
public class MixinMinecraftServer {
	private FeatureTemplateManager templateManager;

	@Inject(
		method = "<init>",
		at = @At("TAIL")
	)
	public void MinecraftServer(CallbackInfo callback) {
		this.templateManager = new FeatureTemplateManager((MinecraftServer) (Object) this, this.getResourceManager());
	}
	
	public FeatureTemplateManager ultraterraforged$UTFMinecraftServer$getFeatureTemplateManager() {
		return this.templateManager;
	}
	
	@Inject(
		method = "method_29440",
		at = @At("TAIL")
	)
	private void method_29440(CallbackInfo callback) {
		this.templateManager.onReload(this.getResourceManager());
	}

	@Shadow
	private ResourceManager getResourceManager() {
		throw new UnsupportedOperationException();
	}
}
