package com.pandaismyname1.ultraterraforged.fabric.mixin;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import net.minecraft.client.gui.screens.worldselection.PresetEditor;
import com.pandaismyname1.ultraterraforged.data.preset.UTFWorldPresets;
import com.pandaismyname1.ultraterraforged.client.gui.screen.presetconfig.PresetConfigScreen;

@Deprecated 
@Mixin(PresetEditor.class)
interface MixinPresetEditor {
	
	// there has to be a better way to do this right?
	@Redirect(
		method = "<clinit>",
		at = @At(
			value = "INVOKE",
			target = "Ljava/util/Map;of(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;"
		),
		remap = false
	)
	private static Map<Object, Object> of(Object k1, Object v1, Object k2, Object v2) {
		Map<Object, Object> map = new HashMap<>();
		map.put(k1, v1);
		map.put(k2, v2);
		map.put(Optional.of(UTFWorldPresets.ULTRATERRAFORGED), (PresetEditor) (screen, ctx) -> new PresetConfigScreen(screen));
		return map;
    }
}
