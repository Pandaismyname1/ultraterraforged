package com.pandaismyname1.ultraterraforged.world.worldgen.biome.spawn;

import java.util.List;
import java.util.Map;

import com.mojang.serialization.Codec;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderGetter;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.levelgen.SpawnTargetPoint;
import net.minecraft.world.level.levelgen.densityfunction.DensityFunction;
import com.pandaismyname1.ultraterraforged.data.preset.PresetNoiseRouterData;
import com.pandaismyname1.ultraterraforged.world.worldgen.GeneratorContext;
import com.pandaismyname1.ultraterraforged.world.worldgen.util.PosUtil;

public enum SpawnType implements StringRepresentable {
    CONTINENT_CENTER("CONTINENT_CENTER") {
        private static final Climate.Parameter FULL_RANGE = Climate.Parameter.span(-1.0F, 1.0F);
        private static final Climate.Parameter INLAND_CONTINENTALNESS = Climate.Parameter.span(-0.11F, 0.55F);

		@Override
    	public BlockPos getSearchCenter(GeneratorContext ctx) {
    		long center = ctx.localHeightmap.get().continent().getNearestCenter(0.0F, 0.0F);
    		return new BlockPos(PosUtil.unpackLeft(center), 0, PosUtil.unpackRight(center));
    	}

		// inland, anywhere in the climate
		@Override
		public List<SpawnTargetPoint> getTargetPoints(HolderGetter<DensityFunction> functions) {
			return List.of(new SpawnTargetPoint(Map.of(
				functions.getOrThrow(PresetNoiseRouterData.OVERWORLD.temperature()), FULL_RANGE,
				functions.getOrThrow(PresetNoiseRouterData.OVERWORLD.vegetation()), FULL_RANGE,
				functions.getOrThrow(PresetNoiseRouterData.OVERWORLD.continents()), Climate.Parameter.span(INLAND_CONTINENTALNESS, FULL_RANGE),
				functions.getOrThrow(PresetNoiseRouterData.OVERWORLD.erosion()), FULL_RANGE,
				functions.getOrThrow(PresetNoiseRouterData.RIDGES), FULL_RANGE
			)));
		}
	},
    ISLANDS("ISLANDS") {

		@Override
		public BlockPos getSearchCenter(GeneratorContext ctx) {
			return BlockPos.ZERO;
		}

		@Override
		public List<SpawnTargetPoint> getTargetPoints(HolderGetter<DensityFunction> functions) {
			return List.of();
		}
	},
    WORLD_ORIGIN("WORLD_ORIGIN") {

		@Override
		public BlockPos getSearchCenter(GeneratorContext ctx) {
			return BlockPos.ZERO;
		}

		@Override
		public List<SpawnTargetPoint> getTargetPoints(HolderGetter<DensityFunction> functions) {
			return List.of();
		}
	};

	public static final Codec<SpawnType> CODEC = StringRepresentable.fromEnum(SpawnType::values);

	private String name;

	private SpawnType(String name) {
		this.name = name;
	}

	@Override
	public String getSerializedName() {
		return this.name;
	}

	public abstract BlockPos getSearchCenter(GeneratorContext ctx);

	// where around the search center the spawn may be, as the noise settings' spawn target; none spawns at the center
	public abstract List<SpawnTargetPoint> getTargetPoints(HolderGetter<DensityFunction> functions);
}
