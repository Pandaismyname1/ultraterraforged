package com.pandaismyname1.ultraterraforged.mixin;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Function;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.mojang.datafixers.util.Either;

import net.minecraft.server.level.ChunkHolder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ThreadedLevelLightEngine;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.chunk.ChunkStatus;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;
import com.pandaismyname1.ultraterraforged.world.worldgen.GeneratorContext;
import com.pandaismyname1.ultraterraforged.world.worldgen.UTFRandomState;
import com.pandaismyname1.ultraterraforged.world.worldgen.WorldGenFlags;
import com.pandaismyname1.ultraterraforged.world.worldgen.rivermap.FrozenFalls;

// Targets are ChunkStatus lambdas, which have no Mojang names: method_* is the Fabric intermediary (and dev) name, m_*_ the Forge/NeoForge 1.20.1 SRG name.
@Mixin(ChunkStatus.class)
public class MixinChunkStatus {

	//structure starts
	@Inject(
		at = @At("HEAD"),
		method = { "method_39464", "m_289181_" },
		remap = false
	)
	private static void method_39464$HEAD(ChunkStatus status, Executor executor, ServerLevel level, ChunkGenerator generator, StructureTemplateManager templateManager, ThreadedLevelLightEngine lightEngine, Function<ChunkAccess, CompletableFuture<Either<ChunkAccess, ChunkHolder.ChunkLoadingFailure>>> chunkLookup, List<ChunkAccess> regionChunks, ChunkAccess centerChunk, CallbackInfoReturnable<CompletableFuture<ChunkAccess>> callback) {
		RandomState randomState = level.getChunkSource().randomState();
		if((Object) randomState instanceof UTFRandomState utfRandomState) {
			ChunkPos chunkPos = centerChunk.getPos();
			@Nullable
			GeneratorContext context = utfRandomState.generatorContext();
			
			if(context != null) {
				context.cache.queueAtChunk(chunkPos.x, chunkPos.z);

				WorldGenFlags.setFastCellLookups(false);
			}
		}
	}
	
	@Inject(
		at = @At("TAIL"),
		method = { "method_39464", "m_289181_" },
		remap = false
	)
	private static void method_39464$TAIL(ChunkStatus status, Executor executor, ServerLevel level, ChunkGenerator generator, StructureTemplateManager templateManager, ThreadedLevelLightEngine lightEngine, Function<ChunkAccess, CompletableFuture<Either<ChunkAccess, ChunkHolder.ChunkLoadingFailure>>> chunkLookup, List<ChunkAccess> regionChunks, ChunkAccess centerChunk, CallbackInfoReturnable<CompletableFuture<ChunkAccess>> callback) {
		RandomState randomState = level.getChunkSource().randomState();
		if((Object) randomState instanceof UTFRandomState utfRandomState) {
			@Nullable
			GeneratorContext context = utfRandomState.generatorContext();
			if(context != null) {
				WorldGenFlags.setFastCellLookups(true);
			}
		}
	}
	
	//features
	@Inject(
		at = @At("TAIL"),
		method = { "method_51375", "m_279978_" },
		remap = false
	)
	private static void method_51375(ChunkStatus status, ServerLevel level, ChunkGenerator generator, List<ChunkAccess> chunks, ChunkAccess centerChunk, CallbackInfo callback) {
		RandomState randomState = level.getChunkSource().randomState();
		if((Object) randomState instanceof UTFRandomState utfRandomState) {
			ChunkPos chunkPos = centerChunk.getPos();
			@Nullable
			GeneratorContext context = utfRandomState.generatorContext();
			
			if(context != null) {
				// after freezing, so falls on frozen rivers freeze too
				if(context.preset.rivers().raisedWater) {
					FrozenFalls.apply(centerChunk, chunks, context);
				}
				context.cache.dropAtChunk(chunkPos.x, chunkPos.z);
			}
		}
	}
}
