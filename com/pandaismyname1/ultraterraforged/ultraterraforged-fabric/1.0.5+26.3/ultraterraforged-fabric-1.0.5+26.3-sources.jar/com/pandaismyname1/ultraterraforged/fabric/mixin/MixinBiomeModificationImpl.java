package com.pandaismyname1.ultraterraforged.fabric.mixin;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Predicate;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.google.common.base.Suppliers;

import net.fabricmc.fabric.api.biome.v1.BiomeModificationContext;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext;
import net.fabricmc.fabric.api.biome.v1.ModificationPhase;
import net.fabricmc.fabric.impl.biome.modification.BiomeModificationImpl;
import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.biome.FeatureSorter;
import net.minecraft.world.level.chunk.ChunkGenerator;
import com.pandaismyname1.ultraterraforged.UTFCommon;
import com.pandaismyname1.ultraterraforged.registries.UTFRegistries;
import com.pandaismyname1.ultraterraforged.world.worldgen.biome.modifier.BiomeModifier;
import com.pandaismyname1.ultraterraforged.world.worldgen.biome.modifier.fabric.FabricBiomeModifier;

@Mixin(BiomeModificationImpl.class)
public class MixinBiomeModificationImpl {
	@Shadow(remap = false)
	@Final
	private static Comparator<Object> MODIFIER_ORDER_COMPARATOR;
	
	private static final Constructor<?> CTOR;
	
	// the registries finalizeWorldGen works on, for getSortedModifiers, which takes them only in newer Fabric APIs
	private static final ThreadLocal<RegistryAccess> REGISTRIES = new ThreadLocal<>();

	@Inject(method = "finalizeWorldGen", at = @At("HEAD"), remap = false)
	private void finalizeWorldGen$HEAD(RegistryAccess registries, CallbackInfo callback) {
		REGISTRIES.set(registries);
	}

	/**
	 * UTF's biome modifiers join Fabric API's, in its order. getSortedModifiers took nothing before Fabric API 0.165
	 * (26.3) and takes the registries since, to add data-driven modifiers (#21): this matches both, as it names no
	 * arguments.
	 */
	@Inject(method = "getSortedModifiers", at = @At("RETURN"), cancellable = true, remap = false)
	private void getSortedModifiers$RETURN(CallbackInfoReturnable<List<Object>> callback) {
		RegistryAccess registries = REGISTRIES.get();
		if (registries == null) {
			return;
		}
		List<Object> modifiers = new ArrayList<>(callback.getReturnValue());
		for(Holder.Reference<BiomeModifier> holder : registries.lookupOrThrow(UTFRegistries.BIOME_MODIFIER).listElements().toList()) {
			if(holder.value() instanceof FabricBiomeModifier modifier) {
				Identifier id = holder.key().identifier();
				Object record = this.makeModifierRecord(id, ModificationPhase.POST_PROCESSING, (ctx) -> {
					return true;
				}, (selection, modification) -> {
					// one modifier failing on one biome shouldn't stop the world from loading
					try {
						modifier.apply(selection, modification);
					} catch (RuntimeException e) {
						UTFCommon.LOGGER.error("Biome modifier {} failed on biome {}", id, selection.getBiomeKey().identifier(), e);
					}
				});
				if (record != null) {
					modifiers.add(record);
				}
			}
		}
		modifiers.sort(MODIFIER_ORDER_COMPARATOR);
		callback.setReturnValue(modifiers);
	}

	/**
	 * Vanilla works out the order of the biomes' features once, and in singleplayer the client already did, before the
	 * server got here. Fabric works it out again only when a modifier changed features through its own context, which
	 * ours don't: they change the biome. Without this the order lacks UTF's trees and features, and decorating a chunk
	 * that has one fails with "Index -1 out of bounds".
	 */
	@Inject(method = "finalizeWorldGen", at = @At("TAIL"), remap = false)
	private void finalizeWorldGen$TAIL(RegistryAccess registries, CallbackInfo callback) {
		REGISTRIES.remove();
		boolean modified = registries.lookupOrThrow(UTFRegistries.BIOME_MODIFIER).stream().anyMatch((modifier) -> modifier instanceof FabricBiomeModifier);
		if (!modified) {
			return;
		}
		registries.lookupOrThrow(Registries.LEVEL_STEM).forEach((stem) -> {
			ChunkGenerator generator = stem.generator();
			ChunkGeneratorAccessor accessor = (ChunkGeneratorAccessor) generator;
			var settings = accessor.getGenerationSettingsGetter();
			accessor.setFeaturesPerStep(Suppliers.memoize(() -> {
				return FeatureSorter.buildFeaturesPerStep(List.copyOf(generator.getBiomeSource().possibleBiomes()), (biome) -> settings.apply(biome).features(), true);
			}));
		});
	}
	
	// Fabric API's record of a modifier, made through reflection as it's internal: null, with the reason logged, if
	// this Fabric API's record doesn't take what it used to
	private Object makeModifierRecord(Identifier id, ModificationPhase phase, Predicate<BiomeSelectionContext> selector, BiConsumer<BiomeSelectionContext, BiomeModificationContext> modifier) {
		if (CTOR == null) {
			UTFCommon.LOGGER.error("Can't add biome modifier {}: this Fabric API's biome modification records aren't made as expected", id);
			return null;
		}
		Class<?>[] types = CTOR.getParameterTypes();
		Object[] args = new Object[types.length];
		for (int i = 0; i < types.length; i++) {
			for (Object arg : new Object[] { phase, id, selector, modifier }) {
				if (types[i].isInstance(arg)) {
					args[i] = arg;
				}
			}
		}
		try {
			return CTOR.newInstance(args);
		} catch (ReflectiveOperationException | RuntimeException e) {
			UTFCommon.LOGGER.error("Can't add biome modifier {}", id, e);
			return null;
		}
	}
	
	static {
		Constructor<?> ctor = null;
		try {
			// the record's fields have been reordered before: take the constructor that takes these four, in any order
			for (Constructor<?> candidate : Class.forName("net.fabricmc.fabric.impl.biome.modification.BiomeModificationImpl$ModifierRecord").getDeclaredConstructors()) {
				List<Class<?>> types = List.of(candidate.getParameterTypes());
				if (types.size() == 4 && types.containsAll(List.of(ModificationPhase.class, Identifier.class, Predicate.class, BiConsumer.class))) {
					candidate.setAccessible(true);
					ctor = candidate;
				}
			}
		} catch (ClassNotFoundException | SecurityException e) {
			UTFCommon.LOGGER.error("Fabric API's biome modification records weren't found", e);
		}
		CTOR = ctor;
	}
}
