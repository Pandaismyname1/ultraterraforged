package com.pandaismyname1.ultraterraforged.world.worldgen.noise.domain;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;

import com.pandaismyname1.ultraterraforged.world.worldgen.noise.module.Noise.Visitor;

public record DirectWarp() implements Domain {
	public static final Codec<DirectWarp> CODEC = MapCodec.unit(DirectWarp::new).codec();
	
	@Override
	public float getOffsetX(float x, float z, int seed) {
		return 0.0F;
	}

	@Override
	public float getOffsetZ(float x, float z, int seed) {
		return 0.0F;
	}

	@Override
	public Domain mapAll(Visitor visitor) {
		return this;
	}

	@Override
	public Codec<DirectWarp> codec() {
		return CODEC;
	}
}
