package com.pandaismyname1.ultraterraforged.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.progress.LevelLoadListener;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.storage.ServerLevelData;
import com.pandaismyname1.ultraterraforged.data.preset.PresetData;
import com.pandaismyname1.ultraterraforged.registries.UTFRegistries;
import com.pandaismyname1.ultraterraforged.world.worldgen.UTFRandomState;
import com.pandaismyname1.ultraterraforged.world.worldgen.biome.UTFClimateSampler;

@Mixin(MinecraftServer.class)
class MixinMinecraftServer {

	@Inject(
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/level/biome/Climate$Sampler;findSpawnPosition()Lnet/minecraft/core/BlockPos;"
		),
		method = "setInitialSpawn"
	)
    private static void findSpawnPosition(ServerLevel serverLevel, ServerLevelData serverLevelData, boolean bl, boolean bl2, LevelLoadListener loadListener, CallbackInfo callback) {
		RandomState randomState = serverLevel.getChunkSource().randomState();
		Climate.Sampler sampler = randomState.sampler();
		serverLevel.registryAccess().lookup(UTFRegistries.PRESET).flatMap((registry) -> {
			return registry.get(PresetData.PRESET);
		}).ifPresent((preset) -> {
			if((Object) randomState instanceof UTFRandomState utfRandomState && (Object) sampler instanceof UTFClimateSampler utfClimateSampler) {
				// an overworld that doesn't read the cells (a datapack's own noise settings) has no terrain of ours to
				// search: vanilla's search, from 0,0
				if(utfRandomState.generatorContext() != null) {
					BlockPos searchCenter = preset.value().world().properties.spawnType.getSearchCenter(utfRandomState.generatorContext());
					utfClimateSampler.setSpawnSearchCenter(searchCenter);
				}
			} else {
				throw new IllegalStateException();
			}
		});
    }
}
